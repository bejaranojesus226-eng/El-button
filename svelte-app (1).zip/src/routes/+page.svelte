<script>
	import '../app.css';
	import App from './App.svelte';
</script>

<App />
